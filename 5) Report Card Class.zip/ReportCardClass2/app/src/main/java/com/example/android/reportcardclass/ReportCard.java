package com.example.android.reportcardclass;


import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReportCard {


    static final private String SCHOOL_NAME = "Grandma's Radical Boys";
    static final private int MIN_YEARS = 1;
    static final private int MAX_YEARS = 12;

    static final private String GRADE_EXCELLENT = "Perfection";
    static final private String GRADE_VERY_GOOD = "Getting Close";
    static final private String GRADE_GOOD = "Good Enough";
    static final private String GRADE_AVERAGE = "You can do Better";
    static final private String GRADE_MIN_PASS = "Minimum";
    static final private String GRADE_FAIL = "You Shall Not Pass";


    private String mStudentName;
    private String mTeacherName;
    private int mStudentYear;
    private char mFinalGrade;
    private String mFinalGradeDesc;
    private String mMessage;

    private ArrayList<SubjectMark> mSubjectMarks;

    public ReportCard (String studentName, String teacherName, int studentYear,
                       ArrayList<SubjectMark> subjectMarks, String message) {
        setStudentName(studentName);
        setTeacherName(teacherName);
        setStudentName(studentYear);
        mSubjectMarks = subjectMarks;
        setMessage(message);
    }

    public void setStudentName(String studentName) {
        mStudentName = formatName(studentName);
    }

    public String getStudentName() {
        return mStudentName;
    }

    public void setTeacherName(String teacherName) {
        mTeacherName = formatName(teacherName);
    }

    public String getTeacherName() {
        return mTeacherName;
    }

    public void setStudentName(int studentYear) {
        mStudentYear = validateStudentYear(studentYear);
    }

    public int getStudentYear() {
        return mStudentYear;
    }

    public void setMessage(String message) {
        mMessage = message.trim();
    }

    public String getMessage() {
        return mMessage;
    }

    public String formatName(String name) {
        String formattedName = "";
        formattedName = toTitleCase(sanitizeName(name));
        return formattedName;
    }

    public String sanitizeName(String name) {
        String sanitizedName = "";

        String patternName = "[a-zA-z]+([ '-][a-zA-Z]+)*";

        Pattern pattern = Pattern.compile(patternName);
        Matcher matcher = pattern.matcher(name);

        if (!matcher.matches()) {
            sanitizedName = name.replaceAll("[^a-zA-Z-\' ]+", "");
        } else {
            sanitizedName = name;
        }

        return sanitizedName;
    }

    public String toTitleCase(String name) {
        String capitalizedName = "";
        boolean isSpace = true;
        int nameLength = 0;

        StringBuilder stringBuilder = new StringBuilder(name);
        nameLength = stringBuilder.length();

        for (int i = 0; i < nameLength; i++) {
            char c = stringBuilder.charAt(i);
            if (isSpace) {
                if (!Character.isWhitespace(c)) {
                    stringBuilder.setCharAt(i, Character.toUpperCase(c));
                    isSpace = false;
                }
            } else if (Character.isWhitespace(c)) {
                isSpace = true;
            } else {
                stringBuilder.setCharAt(i, Character.toLowerCase(c));
            }
        }

        capitalizedName = stringBuilder.toString();
        return capitalizedName;
    }

    public int validateStudentYear (int year) {
        int validatedYear = 0;

        if ((year < MIN_YEARS) || (year > MAX_YEARS)) {
            validatedYear = 1;
        } else {
            validatedYear = year;
        }

        return validatedYear;
    }

    public void setSubjectMarks(String subject, int marks) {
        SubjectMark subjectMark = new SubjectMark(subject, marks);
    }

    @Override
    public String toString() {
        return prepareOutput();
    }

    public String prepareOutput() {
        String strOutput = "";

        // Prepare string output for Subject & Marks list
        StringBuilder displaySubjectMarks = new StringBuilder();
        for (SubjectMark sm : mSubjectMarks) {
            displaySubjectMarks.append(sm.getSubject() + " - " + sm.getMarks() + "\n");
        }

        prepareFinalGrade();

        strOutput = "School = " + SCHOOL_NAME + "\n" +
                "Student Name = " + mStudentName + "\n" +
                "Teacher Name = " + mTeacherName + "\n" +
                "Student Year = " + mStudentYear + "\n\n" +
                "Grades" + "\n" +
                "################" + "\n" +
                displaySubjectMarks.toString() + "\n\n" +
                "Final Grade = " + mFinalGrade + " (" + mFinalGradeDesc + ")\n\n\n" +
                "Final Thoughts " + "\n" +
                mMessage
        ;

        return strOutput;
    }


    public void prepareFinalGrade() {
        int totalMarks = 0;
        int averageMarks = 0;
        int listSize = mSubjectMarks.size();

        for (SubjectMark sm : mSubjectMarks) {
            totalMarks += sm.getMarks();
        }

        averageMarks = (totalMarks / listSize);
        if (averageMarks >= 90) {
            mFinalGrade = 'A';
            mFinalGradeDesc = GRADE_EXCELLENT;
        } else if (averageMarks < 90 && averageMarks >= 80) {
            mFinalGrade = 'B';
            mFinalGradeDesc = GRADE_VERY_GOOD;
        } else if (averageMarks < 80 && averageMarks >= 60) {
            mFinalGrade = 'C';
            mFinalGradeDesc = GRADE_GOOD;
        } else if (averageMarks < 60 && averageMarks >= 50) {
            mFinalGrade = 'D';
            mFinalGradeDesc = GRADE_AVERAGE;
        } else if (averageMarks < 50 && averageMarks >= 40) {
            mFinalGrade = 'E';
            mFinalGradeDesc = GRADE_MIN_PASS;
        } else if (averageMarks < 40) {
            mFinalGrade = 'F';
            mFinalGradeDesc = GRADE_FAIL;
        }
    }
}


class SubjectMark {
    static final private int MIN_SCORE = 0;
    static final private int MAX_SCORE = 100;
    private String mSubject;
    private int mMarks;

    public SubjectMark(String subject, int marks) {
        setSubject(subject);
        setMarks(marks);
    }


    public void setSubject(String subject) {
        mSubject = formatSubject(subject);
    }

    public String getSubject() {
        return mSubject;
    }


    public void setMarks(int marks) {
        mMarks = validateMarks(marks);
    }

    public int getMarks() {
        return mMarks;
    }

    private String formatSubject(String subject) {
        String formattedSubject = "";

        String patternSubject = "^[a-zA-Z]+( [a-zA-z]+)*$";

        Pattern pattern = Pattern.compile(patternSubject);
        Matcher matcher = pattern.matcher(subject);

        if (!matcher.matches()) {
            formattedSubject = subject.replaceAll("[^a-zA-Z ]+", "");
        } else {
            formattedSubject = subject;
        }

        return formattedSubject;
    }


    public int validateMarks(int marks) {
        int validatedMarks = 0;

        if ((marks < MIN_SCORE) || (marks > MAX_SCORE)) {
            validatedMarks = MIN_SCORE;
        } else {
            validatedMarks = marks;
        }

        return validatedMarks;
    }
}

