package com.example.android.reportcardclass;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static final private String LOG_TAG = "ReportCardClass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<SubjectMark> result = new ArrayList<SubjectMark>();
        result.add(new SubjectMark("Defense", 72));
        result.add(new SubjectMark("Biology", 85));
        result.add(new SubjectMark("Physics", 92));
        result.add(new SubjectMark("Chemistry", 95));
        result.add(new SubjectMark("Mathematics", 98));
        result.add(new SubjectMark("Orc History", 100));
        result.add(new SubjectMark("Aeronautics", 83));
        result.add(new SubjectMark("Gnomish", 68));
        result.add(new SubjectMark("Technology", 45));

        ReportCard reportCard = new ReportCard("Jack Finn", "Grandma Cecile", 5, result,
                "Enjoy you Summer\nAcademy returns on August 13th\nDon't do nothing I wouldn't do");

        String output = reportCard.toString();
        Log.v(LOG_TAG, output);

        TextView textView = (TextView) findViewById(R.id.text_output);
        textView.setText(output);
    }
}
