# ScoreKeeper
Game of Belamento, a traditional Easter game in my family.

Rules of Game:
Thrice a day, you must first say "Belamento" to your adversary to gain points.
At the end of #amout of days, previously aggred upon among eachpther, till easter, the one with the most points wins an Easter egg bought by the loser
