package com.example.android.tourguide;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.example.android.tourguide.helper.DatabaseHelper;
import com.example.android.tourguide.model.City;
import com.example.android.tourguide.model.Places;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    /** All UI components */
    private TextView mTextLondon;
    private TextView mTextParis;
    private TextView mTextRome;
    private TextView mTextNewYork;

    /** Various identifiers */
    private Typeface mCustomFont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolBar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolBar);

        // Initialize UI components
        mTextLondon = (TextView) findViewById(R.id.text_select_terceira);
        mTextParis = (TextView) findViewById(R.id.text_select_pico);
        mTextRome = (TextView) findViewById(R.id.text_select_smiguel);

        // Set custom typeface
        mCustomFont = Typeface.createFromAsset(getAssets(), "fonts/opensans_semibold.ttf");
        setCustomTypeface();

        // Set OnClickListeners on clickable TextViews
        mTextLondon.setOnClickListener(this);
        mTextParis.setOnClickListener(this);
        mTextRome.setOnClickListener(this);
        mTextNewYork.setOnClickListener(this);

        // Create and populate tables if they do not exist
        insertCitiesRecords();
        insertPlacesRecords();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
    }

    /**
     * This method sets custom font for all views
     */
    public void setCustomTypeface() {
        mTextLondon.setTypeface(mCustomFont);
        mTextParis.setTypeface(mCustomFont);
        mTextRome.setTypeface(mCustomFont);
        mTextNewYork.setTypeface(mCustomFont);
    }

    /**
     * This method invokes methods for clicked items
     * @param view
     */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.text_select_terceira:
                openTourActivity(getString(R.string.label_terceira));
                break;
            case R.id.text_select_pico:
                openTourActivity(getString(R.string.label_pico));
                break;
            case R.id.text_select_smiguel:
                openTourActivity(getString(R.string.label_smiguel));
                break;
            default:
                openTourActivity(getString(R.string.label_terceira));
                break;
        }
    }

    /**
     * This method invokes TourActivity with content for selected city
     * @param selectedCity
     */
    public void openTourActivity(String selectedCity) {
        Intent intent = new Intent(MainActivity.this, TourActivity.class);
        intent.putExtra("city", selectedCity);
        startActivity(intent);
    }

    /**
     * This method creates and populates Cities table
     */
    public void insertCitiesRecords() {
        int [] imageResources = {R.drawable.angra, R.drawable.pico, R.drawable.smiguel};
        String [] record = new String[7];
        String [] records = getResources().getStringArray(R.array.islands_array);
        int rowCount = 0;

        DatabaseHelper db = new DatabaseHelper(getApplicationContext());

        rowCount = db.getCitiesRowsCount();

        if (rowCount == 0) {
            for (int i = 0; i < records.length; i++) {
                record = records[i].split("\\|");

                db.createCity(new City(Integer.parseInt(record[0]), record[1], record[2],
                        record[3], record[4], record[5], record[6], record[7], record[8],
                        imageResources[i]
                ));
            }
        }
    }

    /**
     * This method creates and populates Places table
     */
    public void insertPlacesRecords() {
        String [] record = new String[8];
        String [] records = getResources().getStringArray(R.array.places_array);
        int rowCount = 0;

        DatabaseHelper db = new DatabaseHelper(getApplicationContext());

        rowCount = db.getPlacesRowsCount();

        if (rowCount == 0) {
            for (int i = 0; i < records.length; i++) {
                record = records[i].split("\\|");

                db.createPlaces(new Places(Integer.parseInt(record[0]), record[1], record[2],
                        record[3], record[4], record[5], record[6], Integer.parseInt(record[7]), record[8]
                ));
            }
        }
    }

}
