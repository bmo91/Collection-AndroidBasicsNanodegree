package com.example.android.tourguide;


import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.android.tourguide.helper.DatabaseHelper;
import com.example.android.tourguide.model.Places;

import java.util.List;

public class PlaceActivity extends AppCompatActivity {

    private static final String LOG_TAG = PlaceActivity.class.getSimpleName();
    private static final int IMAGE_RIGHT_MARGIN = 50;
    private static final int NUM_FLOATING_LINES = 10;

    /** All UI components */
    private TextView mTextViewPlaceDesc;
    private ImageView mImageViewPlace;
    private Button mButtonWebsite;

    /** Various identifiers */
    private Typeface mCustomFont;
    private Typeface mCustomFontBold;
    private int mPlaceId;
    private String mCity;
    private String mPlaceName;
    private String mPlaceDesc;
    private String mPlaceImage;
    private String mPlaceWebsite;
    private int mResourceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place);



        // Get Place ID from Intent Extras
        if (getIntent().getExtras() != null) {
            Bundle bundle = getIntent().getExtras();
            mPlaceId = bundle.getInt("placeID");
        }

        // Initialize UI components
        mTextViewPlaceDesc = (TextView) findViewById(R.id.text_place_desc);
        mImageViewPlace = (ImageView) findViewById(R.id.image_place);
        mButtonWebsite = (Button) findViewById(R.id.button_web);

        // Set custom typeface
        mCustomFont = Typeface.createFromAsset(getAssets(), "fonts/opensans_regular.ttf");
        mCustomFontBold = Typeface.createFromAsset(getAssets(), "fonts/opensans_bold.ttf");
        setCustomTypeface();

        // Fetch data from table
        fetchPlacesData();

        // Set ActionBar label
        setActionBarTitle();

        // Update UI Elements
        updateUi();

        // Invoke website upon button click
        mButtonWebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(mPlaceWebsite));
                startActivity(intent);
            }
        });

    }

    /**
     * This method sets custom font for all views
     */
    public void setCustomTypeface() {
        mTextViewPlaceDesc.setTypeface(mCustomFont);
        mButtonWebsite.setTypeface(mCustomFontBold);
    }

    /**
     * This method fetches data from PLACES table for the specific Place ID
     */
    public void fetchPlacesData() {
        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        List<Places> places = databaseHelper.readPlacesData(mPlaceId);

        for (Places pl : places) {
            mCity = pl.getCityName().trim();
            mPlaceName = pl.getPlace().trim();
            mPlaceDesc =  pl.getPlaceDesc().trim();
            mPlaceImage = pl.getPlaceImage().trim();
            mPlaceWebsite = pl.getPlaceWebsite().trim();
        }
    }

    /**
     * This method sets Action Bar Title
     */
    public void setActionBarTitle() {
        getSupportActionBar().setTitle(mCity + " : " + mPlaceName);
    }

    /**
     * This method populates all View elements using data fetched from PLACES table
     */
    public void updateUi() {

        // Display Place Image
        displayPlaceImage();

        // Display Place Description
        displayPlaceDesc();
    }

    /**
     * This method displays image of the place
     */
    public void displayPlaceImage() {
        mResourceId = getResources().getIdentifier(mPlaceImage, "drawable", getPackageName());
        mImageViewPlace.setImageResource(mResourceId);
    }

    /**
     * This method displays description of the place
     */
    public void displayPlaceDesc() {

        // Get image as drawable object
        Drawable drawable = ContextCompat.getDrawable(getApplicationContext(), mResourceId);
    }
}

