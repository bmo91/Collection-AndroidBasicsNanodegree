package com.example.android.tourguide;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class TourActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String selectedCity = "";

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour);

        // Get Intent Extras
        if (getIntent().getExtras() != null) {
            Bundle bundle = getIntent().getExtras();
            selectedCity = bundle.getString("city");
        }

        // Change Actionbar Label based on selected city
        getSupportActionBar().setTitle(getSupportActionBar().getTitle() + " : " + selectedCity);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public void setActionBarTitle(String title){
        getSupportActionBar().setTitle(title);
    }

}
