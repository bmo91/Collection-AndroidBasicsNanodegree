package utilities;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.android.bookcatalog.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public final class Utils {

    private void Utils() {
    }


    public static void setCustomTypeface(Context context, View view) {
        Typeface typefaceSourceSerif = Typeface.createFromAsset(context.getAssets(),
                "fonts/sourceserifpro_semibold.otf");
        Typeface typefaceSourceSerifReg = Typeface.createFromAsset(context.getAssets(),
                "fonts/sourceserifpro_regular.otf");
        Typeface typefaceSourceSans = Typeface.createFromAsset(context.getAssets(),
                "fonts/sourcesanspro_semibold.otf");


        String viewTag = view.getTag().toString();

        if (viewTag.equals(context.getString(R.string.tag_textview))) {
            TextView textView = (TextView) view;
            textView.setTypeface(typefaceSourceSerif);
        } else if (viewTag.equals(context.getString(R.string.tag_textview_2))) {
            TextView textView = (TextView) view;
            textView.setTypeface(typefaceSourceSerifReg);
        } else if (viewTag.equals(context.getString(R.string.tag_edittext))) {
            EditText editText = (EditText) view;
            editText.setTypeface(typefaceSourceSerif);
        } else if (viewTag.equals(context.getString(R.string.tag_button))) {
            Button button = (Button) view;
            button.setTypeface(typefaceSourceSans);
        }
    }

    public static boolean checkEmptyString(String input) {
        return input.length() != 0;
    }

    public static boolean checkValidString(String input) {
        String patternName = "[a-zA-z.]+([ '-][a-zA-Z.]+)*";
        Pattern pattern = Pattern.compile(patternName);
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }

}