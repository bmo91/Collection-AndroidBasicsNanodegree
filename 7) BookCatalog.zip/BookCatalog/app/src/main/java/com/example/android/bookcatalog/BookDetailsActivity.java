package com.example.android.bookcatalog;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import utilities.Utils;




public class BookDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String LOG_TAG = MainActivity.class.getName();

    final Context mContext = this;

    // UI Components
    private ImageView mImageThumbnail;
    private TextView mTextTitle;
    private TextView mTextAuthor;
    private TextView mTextPrice;
    private TextView mTextDetails;
    private TextView mTextDesc;
    private Button mButtonBuy;
    private Button mButtonPreview;

    private Book mSelectedBook;
    private String mBuyingLink;
    private String mPreviewLink;
    private String mPublishedDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        int listPosition;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);
        if (getIntent().getExtras() != null) {
            Bundle bundle = getIntent().getExtras();
            listPosition = bundle.getInt("position");

            // Get the book that was clicked on in Book List
            mSelectedBook = BookListActivity.mListBook.get(listPosition);
        }

        /** Initialize UI components */
        mImageThumbnail = (ImageView) findViewById(R.id.image_thumbnail);
        mTextTitle = (TextView) findViewById(R.id.text_title);
        mTextAuthor = (TextView) findViewById(R.id.text_author);
        mTextPrice = (TextView) findViewById(R.id.text_price);
        mTextDetails = (TextView) findViewById(R.id.text_details);
        mTextDesc = (TextView) findViewById(R.id.text_desc);
        mButtonBuy = (Button) findViewById(R.id.button_buy_book);

        setCustomTypeface();

        mButtonBuy.setOnClickListener(this);
        mButtonPreview.setOnClickListener(this);

        displayBookDetails();

    }


    public void setCustomTypeface() {
        Utils.setCustomTypeface(mContext, mTextTitle);
        Utils.setCustomTypeface(mContext, mTextAuthor);
        Utils.setCustomTypeface(mContext, mTextPrice);
        Utils.setCustomTypeface(mContext, mTextDetails);
        Utils.setCustomTypeface(mContext, mTextDesc);
        Utils.setCustomTypeface(mContext, mButtonBuy);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_buy_book:
                launchBuyingLink();
                break;
        }
    }

    public void displayBookDetails() {

        displayTitle();         // Display book title
        displayAuthor();        // Display author of the book
        displayPrice();         // Display price of the book
        setBuyingLink();        // Set buying link for button
        setPreviewLink();       // Set preview link for button
        formatDate();           // Get formatted Published Date
        displayDetails();       // Display book details
        displayDescription();   // Display book description
    }



    public void displayTitle() {
        mTextTitle.setText(mSelectedBook.getTitle());
    }

    public void displayAuthor() {
        String author = mSelectedBook.getAuthor();

        if (author != null && author.length() > 0) {
            mTextAuthor.setText(author);
        } else {
            mTextAuthor.setText(getString(R.string.info_no_author));
        }
    }

    public void displayPrice() {
        double price = mSelectedBook.getRetailPrice();
        String retailPrice;

        if (price != 0.00) {
            retailPrice = mSelectedBook.getCurrencyCode() + " " + price;
        } else {
            retailPrice = getString(R.string.info_no_price);
        }

        mTextPrice.setText(retailPrice);
    }


    public void setBuyingLink() {
        mBuyingLink = mSelectedBook.getBuyingLink();

        if (mBuyingLink != null && mBuyingLink.length() == 0) {
            mButtonBuy.setVisibility(View.GONE);
        }
    }

    public void setPreviewLink() {
        mPreviewLink = mSelectedBook.getPreviewlLink();

        if (mPreviewLink != null && mPreviewLink.length() == 0) {
            mButtonPreview.setVisibility(View.GONE);
        }
    }

    public void launchBuyingLink() {
        Uri bookBuyingURL = Uri.parse(mBuyingLink);
        Intent webIntent = new Intent(Intent.ACTION_VIEW, bookBuyingURL);
        startActivity(webIntent);
    }

    public void launchPreviewLink() {
        Uri bookPreviewURL = Uri.parse(mPreviewLink);
        Intent webIntent = new Intent(Intent.ACTION_VIEW, bookPreviewURL);
        startActivity(webIntent);
    }


    public void formatDate() {
        String date = mSelectedBook.getPublishedDate();
        String dateNew = "";
        mPublishedDate = "";

        if (date != null && date.length() != 0) {
            if (date.length() == 4 || date.length() == 7 || date.length() == 10 ) { // check if date is YYYY or YYYY-MM or YYYY-MM-DD
                dateNew = date;
            } else if (date.length() > 10) {
                dateNew = date.substring(0, 10);
            }

            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat newFormat = new SimpleDateFormat("MMM yyyy");
            try {
                Date dt = inputFormat.parse(dateNew);
                mPublishedDate = newFormat.format(dt);
            }
            catch(ParseException pe) {
                Log.e(LOG_TAG, mContext.getString(R.string.exception_date_format), pe);
            }
        }
    }


    public void displayDetails() {
        String category;
        String printType;
        String language;
        int pageCount;

        StringBuilder sbDetails = new StringBuilder();

        if (mPublishedDate != null && mPublishedDate.length() > 0) {
            sbDetails.append(String.format(getString(R.string.label_published), mPublishedDate));
            sbDetails.append(getString(R.string.newline));
        }

        category = mSelectedBook.getCategories();
        if (category != null && category.length() > 0) {
            sbDetails.append(String.format(getString(R.string.label_category), category));
            sbDetails.append(getString(R.string.newline));
        }

        printType = mSelectedBook.getPrintType();
        if (printType != null && printType.length() > 0) {
            sbDetails.append(String.format(getString(R.string.label_print_type), printType));
            sbDetails.append(getString(R.string.newline));
        }

        if ((mSelectedBook.getLanguage() != null) && (mSelectedBook.getLanguage().length() > 0)) {
            Locale locale = new Locale(mSelectedBook.getLanguage());
            language = locale.getDisplayLanguage(locale);
            sbDetails.append(String.format(getString(R.string.label_language), language));
            sbDetails.append(getString(R.string.newline));
        }

        // Add Page Count
        pageCount = mSelectedBook.getPageCount();
        if (pageCount != 0) {
            sbDetails.append(String.format(getString(R.string.label_page_count), pageCount));
            sbDetails.append(getString(R.string.newline));
        }

        if (mSelectedBook.isTagEpub()) {
            sbDetails.append(getString(R.string.label_epub)).append(getString(R.string.label_avail));
            sbDetails.append(getString(R.string.newline));
        } else {
            sbDetails.append(getString(R.string.label_epub)).append(getString(R.string.label_noavail));
            sbDetails.append(getString(R.string.newline));
        }

        if (mSelectedBook.isTagPdf()) {
            sbDetails.append(getString(R.string.label_pdf)).append(getString(R.string.label_avail));
            sbDetails.append(getString(R.string.newline));
        } else {
            sbDetails.append(getString(R.string.label_pdf)).append(getString(R.string.label_noavail));
            sbDetails.append(getString(R.string.newline));
        }

        mTextDetails.setText(sbDetails.toString());
    }

    /**
     * Method to display Book description
     */
    public void displayDescription() {
        String description = mSelectedBook.getDescription();
        if (description != null && description.length() > 0) {
            mTextDesc.setText(description);
        } else {
            mTextDesc.setText(getString(R.string.info_no_desc));
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
