package com.example.android.bookcatalog;


public class Book {


    private String mTitle;

    /** Book Author */
    private String mAuthor;

    /** Published Date */
    private String mPublishedDate;

    /** Book Categories */
    private String mCategories;

    /** Language */
    private String mLanguage;

    /** Page Count */
    private int mPageCount;

    /** Print Type */
    private String mPrintType;

    /** Retail Price */
    private double mRetailPrice;

    /** Currency Code */
    private String mCurrencyCode;

    /** Buying Link */
    private  String mBuyingLink;

    /** EPUB Tag */
    private boolean mIsEpubAvailable;

    /** PDF Tag */
    private boolean mIsPdfAvailable;

    /** Rating */
    private double mRating;

    /** Description */
    private String mDescription;

    /** Thumbnail Link */
    private String mThumbnailLink;

    /** Preview Link */
    private String mPreviewlLink;

    public Book(String title, String author, String publishedDate, String categories,
                String language, int pageCount, String printType, double retailPrice,
                String currencyCode, String buyingLink, boolean isEpubAvailable,
                boolean isPdfAvailable, double rating, String description, String thumbnailLink,
                String previewLink) {

        mTitle = title;
        mAuthor = author;
        mPublishedDate = publishedDate;
        mCategories = categories;
        mLanguage = language;
        mPageCount = pageCount;
        mPrintType = printType;
        mRetailPrice = retailPrice;
        mCurrencyCode = currencyCode;
        mBuyingLink = buyingLink;
        mIsEpubAvailable = isEpubAvailable;
        mIsPdfAvailable = isPdfAvailable;
        mRating = rating;
        mDescription = description;
        mThumbnailLink = thumbnailLink;
        mPreviewlLink = previewLink;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getAuthor() {
        return mAuthor;
    }

    public void setAuthor(String author) {
        mAuthor = author;
    }

    public String getPublishedDate() {
        return mPublishedDate;
    }

    public void setPublishedDate(String publishedDate) {
        mPublishedDate = publishedDate;
    }

    public String getCategories() {
        return mCategories;
    }

    public void setCategories(String categories) {
        mCategories = categories;
    }

    public String getLanguage() {
        return mLanguage;
    }

    public void setLanguage(String language) {
        mLanguage = language;
    }

    public int getPageCount() {
        return mPageCount;
    }

    public void setPageCount(int pageCount) {
        mPageCount = pageCount;
    }

    public String getPrintType() {
        return mPrintType;
    }

    public void setPrintType(String printType) {
        mPrintType = printType;
    }

    public boolean isTagEpub() {
        return mIsEpubAvailable;
    }

    public void setTagEpub(boolean isEpubAvailable) {
        mIsEpubAvailable = isEpubAvailable;
    }

    public boolean isTagPdf() {
        return mIsPdfAvailable;
    }

    public void setTagPdf(boolean isPdfAvailable) {
        mIsPdfAvailable = isPdfAvailable;
    }

    public double getRating() {
        return mRating;
    }

    public void setRating(double rating) {
        mRating = rating;
    }

    public double getRetailPrice() {
        return mRetailPrice;
    }

    public void setRetailPrice(double retailPrice) {
        mRetailPrice = retailPrice;
    }

    public String getCurrencyCode() {
        return mCurrencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        mCurrencyCode = currencyCode;
    }

    public String getBuyingLink() {
        return mBuyingLink;
    }

    public void setBuyingLink(String buyingLink) {
        mBuyingLink = buyingLink;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public String getThumbnailLink() {
        return mThumbnailLink;
    }

    public void setThumbnailLink(String thumbnailLink) {
        mThumbnailLink = thumbnailLink;
    }

    public String getPreviewlLink() {
        return mPreviewlLink;
    }

    public void setPreviewLink(String previewLink) {
        mPreviewlLink = previewLink;
    }
}
