package com.example.android.bookcatalog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;
import utilities.Utils;



public class BookAdapter extends ArrayAdapter<Book> {
    private static final String LOG_TAG = BookAdapter.class.getName();
    private static final String CURRENCY_GBP = "GBP";
    private static final String CURRENCY_USD = "USD";
    private static final String CURRENCY_EUR = "EUR";
    private static Context mContext;

    public BookAdapter(Context context, List<Book> books) {
        super(context, 0, books);
        mContext = context;
    }

    public static class BookViewHolder {

        TextView textViewTitle;
        TextView textViewAuthor;
        TextView textViewPrice;
        ImageView imageViewBook;

        public BookViewHolder(View itemView) {
            textViewTitle = (TextView) itemView.findViewById(R.id.text_title);
            textViewAuthor = (TextView) itemView.findViewById(R.id.text_author);
            textViewPrice = (TextView) itemView.findViewById(R.id.text_price);
            imageViewBook = (ImageView) itemView.findViewById(R.id.image_thumbnail);

            Utils.setCustomTypeface(mContext, textViewTitle);
            Utils.setCustomTypeface(mContext, textViewAuthor);
            Utils.setCustomTypeface(mContext, textViewPrice);
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        double price = 0;
        String image = "";
        String bookPrice = "";
        String ratingsImage = "";
        BookViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.activity_book_list, parent, false);
            holder = new BookViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (BookViewHolder) convertView.getTag();
        }

        Book currentBook = getItem(position);

        holder.textViewTitle.setText(currentBook.getTitle());

        holder.textViewAuthor.setText(currentBook.getAuthor());

        price = currentBook.getRetailPrice();
        if (price != 0.00) {
            switch (currentBook.getCurrencyCode()) {
                case CURRENCY_GBP:
                    bookPrice = (getContext().getString(R.string.label_gbp, price));
                    break;
                case CURRENCY_USD:
                    bookPrice = (getContext().getString(R.string.label_usd, price));
                    break;
                case CURRENCY_EUR:
                    bookPrice = (getContext().getString(R.string.label_euro, price));
                    break;
            }
        } else {
            bookPrice = getContext().getString(R.string.info_not_priced);
        }
        holder.textViewPrice.setText(bookPrice);
        return convertView;
    }
}